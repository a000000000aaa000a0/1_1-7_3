package koukasokutei3;

// BirdInterfaceインターフェースを定義する。
interface BirdInterface {
    // それぞれの鳥の詳細情報を表示するメソッド。戻り値は返さない。
    void IndicationBirdDetail(int birdNumber);
}





